class InvalidMarksException:
    pass
def marks():
    m=int(input("Enter the marks of student: "))
    if m<0 or m>100:
        raise InvalidMarksException("Marks out of range.")
    return m
try:
    m=marks()
    print("Valid Marks")
except InvalidMarksException as e:
    print("Error,",e)
else:
    print("Student marks entered!")
finally:
    print("Program successfully exceuted!")
