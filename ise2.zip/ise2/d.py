d={"name":["MK","JK","RM","JM"],
   "marks":[90,95,100,80]}
print("Dictionary Records:",d)
