def total(x,y,z):
    return x+y+z
def percentage(x,y,z):
    t=x+y+z
    return t/3
def grade_cal(x,y,z):
    t=(x+y+z)/3
    if t>=90 and t<=100:
        print("A Grade")
    elif t>=75 and t<90:
        print("B Grade")
    elif t>=50 and t<75:
        print("C Grade")
    elif t>=40 and t<50:
        print("Pass")
    else:
        print("Fail")
