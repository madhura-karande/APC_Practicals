from student import result
k=int(input("Enter marks of student for Python: "))
l=int(input("Enter marks of student for java:"))
m=int(input("Enter marks of student for C: "))
print("Total Marks:",result.total(k,l,m))
print("Percentage: ",result.percentage(k,l,m))
print(result.grade_cal(k,l,m))
